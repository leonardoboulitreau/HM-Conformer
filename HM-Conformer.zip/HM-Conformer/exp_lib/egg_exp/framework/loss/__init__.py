from .interface import Criterion
from .classification import *