from . import loss
from . import model

from .deepfake_detection_DA_multiloss import *
