docker build -t env202305 ./Dockerfile
